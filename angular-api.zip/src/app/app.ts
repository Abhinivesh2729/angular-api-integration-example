import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App  implements OnInit{
  protected readonly title = signal('products');
  products: any[] = []

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadProducts()
  }

  loadProducts() {
    this.http.get('http://localhost:3000/api/products').subscribe({
      next: (data: any) => {
        console.log(data)
        this.products = data
        
      }
    })
  }

}
